export const presets = ['@babel/preset-env']
