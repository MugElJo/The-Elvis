declare module 'colorthief/src/color-thief-node'
